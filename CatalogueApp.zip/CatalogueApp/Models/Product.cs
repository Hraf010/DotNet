using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace CatalogueApp.Models{
    public class Product{
        [Display(Name = "Produit ID")]

        [Key]
        public int ProductId { get; set; }
        [Required, MinLength(6), MaxLength(25)]
        public string Name { get; set; }
        [Required, Range(100, 1000000)]
        public double Price { get; set; }
        
        public int CategoryId {get;set;}
        [ForeignKey("CategoryId")]
        public virtual Category category{get; set;}

    }
}