using CatalogueApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;

namespace CatalogueApp.Controllers{
    [Route("/api/products")]
    public class ProductRestController : Controller{
        public CatalogueDBRepository catalogueRepository { get; set; }

        public ProductRestController(CatalogueDBRepository catalogueDBRepository){
            this.catalogueRepository = catalogueDBRepository;
        }

        [HttpGet]
        public IEnumerable<Product> listCats(){
            return catalogueRepository.Products.Include(p=>p.category);
        }
        [HttpGet("search")]
        public IEnumerable<Product> listCatsByMotCle(string mc){
            return catalogueRepository.Products.Include(p=>p.category)
            .Where(p=>p.Name.Contains(mc) );
        }


        [HttpGet("{Id}")]
        public Product GetProduct(int Id){
            return catalogueRepository.Products.Include(p=>p.category).FirstOrDefault(pr=>pr.ProductId==Id);
        }


        [HttpPost]
        public Product Save([FromBody] Product product){
            Console.WriteLine(product.Name);
            catalogueRepository.Products.Add(product);
            catalogueRepository.SaveChanges();
            return product;
        }

        [HttpPut("{Id}")]
        public Product Update([FromBody] Product product , int Id){
            product.ProductId = Id;
            catalogueRepository.Products.Update(product);
            catalogueRepository.SaveChanges();
            return product;
        }

        [HttpDelete("{Id}")]
        public void Delete(int Id){
            Product product = GetProduct(Id);
            catalogueRepository.Products.Remove(product);
            catalogueRepository.SaveChanges();
        }


    }
}