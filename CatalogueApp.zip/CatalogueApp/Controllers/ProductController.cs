using System.Collections.Generic;
using CatalogueApp.Models;
using CatalogueApp.Services;
using Microsoft.AspNetCore.Mvc;
using System;
namespace CatalogueApp.Controllers{
    public class ProductController:Controller{
        private IProductService _productService{get; set;} 

        public ProductController(CatalogueDBRepository catalogueDBRepository){
            this._productService = new ProductServiceImpl(catalogueDBRepository);
        }

         public IActionResult Index()
        {
            IEnumerable<Product> prods = _productService.listCats();
            return View("Products", prods);
        }

        public IActionResult Chercher(string motCle)
		{
            if (motCle == null)
            {
                ModelState.AddModelError("motCle", "ne doit pas �tre nul");
            }
            if (ModelState.IsValid)
            {
                IEnumerable<Product> prods = _productService.listCatsByMotCle(motCle);
                ViewBag.motCle = motCle;
                return View("Products", prods);
            }

            IEnumerable<Product> allProds = _productService.listCats();
            return View("Products", allProds);
        }

        public IActionResult FormProduct()
        {
            Product product = new Product();
            return View(product);
        }

        public IActionResult Save(Product product)
        {
            if (ModelState.IsValid)
            {
                Product p = _productService.Save(product);
                Console.WriteLine(p.ProductId);
                return RedirectToAction("Index");
            }
            return View("FormProduct", product);
        }

        public IActionResult Edit(int Id)
        {
            Product p = _productService.GetProduct(Id);
            return View(p);
        }

        public IActionResult Update(Product product)
        {
            if (ModelState.IsValid)
            {
                Console.WriteLine("Id :"+product.ProductId);
                _productService.Update(product,product.ProductId);
                return RedirectToAction("Index");
            }
            return View("Edit", product);
        }

        public IActionResult Delete(int id)
        {
            _productService.Delete(id);
            return RedirectToAction("Index");
        }

    }


}