using System.Collections.Generic;
using CatalogueApp.Models;
using CatalogueApp.Services;
using Microsoft.AspNetCore.Mvc;
using System;
namespace CatalogueApp.Controllers{
    public class CategoryController:Controller{
        private CategoryServiceImpl _categoryService{get; set;} 

        public CategoryController(CatalogueDBRepository catalogueDBRepository){
            this._categoryService = new CategoryServiceImpl(catalogueDBRepository);
        }

         public IActionResult Index()
        {
            IEnumerable<Category> cats = _categoryService.listCats();
            return View("Categories", cats);
        }

         public IActionResult Products(int Id)
        {
            Category category = _categoryService.getCat(Id);
            ViewBag.Name = category.Name;
            IEnumerable<Product> prods = _categoryService.listProductsByCat(Id);
            return View("Products", prods);
        }

        public IActionResult FormCategory()
        {
            Category category = new Category();
            return View(category);
        }

        public IActionResult Save(Category category)
        {
            if (ModelState.IsValid)
            {
                Category c = _categoryService.Save(category);
                return RedirectToAction("Index");
            }
            return View("FormCategor", category);
        }

        public IActionResult Edit(int Id)
        {
            Category c = _categoryService.getCat(Id);
            return View(c);
        }

        public IActionResult Update(Category category)
        {
            if (ModelState.IsValid)
            {
                Console.WriteLine("Id :"+category.CategoryId);
                _categoryService.Update(category,category.CategoryId);
                return RedirectToAction("Index");
            }
            return View("Edit", category);
        }

        public IActionResult Delete(int id)
        {
            _categoryService.Delete(id);
            return RedirectToAction("Index");
        }

    }


}