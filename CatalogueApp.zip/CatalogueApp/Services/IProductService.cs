using System.Collections.Generic;
using CatalogueApp.Models;

namespace CatalogueApp.Services{
    public interface IProductService
    {
       public IEnumerable<Product> listCats();
       public IEnumerable<Product> listCatsByMotCle(string mc);
       public Product GetProduct(int Id);

       public Product Save(Product product);
    
       public Product Update(Product product , int Id) ;
       public void Delete(int Id);

        
    }
}