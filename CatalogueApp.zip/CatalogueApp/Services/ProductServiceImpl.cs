using System.Collections.Generic;
using System.Linq;
using CatalogueApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

namespace CatalogueApp.Services{
    public class ProductServiceImpl : IProductService
    {
        public CatalogueDBRepository catalogueRepository { get; set; }

        public ProductServiceImpl(CatalogueDBRepository catalogueDBRepository){
            this.catalogueRepository = catalogueDBRepository;
        }
       
        public Product GetProduct(int Id)
        {
            return catalogueRepository.Products.Include(p=>p.category).FirstOrDefault(pr=>pr.ProductId==Id);
        }

        public IEnumerable<Product> listCats()
        {
             return catalogueRepository.Products.Include(p=>p.category);
        }

        public IEnumerable<Product> listCatsByMotCle(string mc)
        {
            return catalogueRepository.Products.Include(p=>p.category)
            .Where(p=>p.Name.Contains(mc) );
        }

        public Product Save(Product product)
        {
            catalogueRepository.Products.Add(product);
            catalogueRepository.SaveChanges();
            return product;
        }

        public Product Update(Product product, int Id)
        {
            product.ProductId = Id;
            catalogueRepository.Products.Update(product);
            Console.WriteLine("Product"+ product.Name);
            catalogueRepository.SaveChanges();
            return product;
        }

         public void Delete(int Id)
        {
            Product product = GetProduct(Id);
            catalogueRepository.Products.Remove(product);
            catalogueRepository.SaveChanges();
        }
    }
}