using CatalogueApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CatalogueApp.Services{
    public class CategoryServiceImpl{
        public CatalogueDBRepository catalogueRepository { get; set; }

        public CategoryServiceImpl(CatalogueDBRepository catalogueDBRepository){
            this.catalogueRepository = catalogueDBRepository;
        }
        public IEnumerable<Category> listCats(){
            return catalogueRepository.Categories;
        }
        public Category getCat(int Id){
            return catalogueRepository.Categories.FirstOrDefault(catalogueRepository=>catalogueRepository.CategoryId==Id);
        }

        
        public IEnumerable<Product> listProductsByCat(int Id){
            Category category =  catalogueRepository.Categories
            .Include(c=>c.Products)
            .FirstOrDefault(catalogueRepository=>catalogueRepository.CategoryId==Id);

            return category.Products;
        }


        public Category Save([FromBody] Category category){
            catalogueRepository.Categories.Add(category);
            catalogueRepository.SaveChanges();
            return category;
        }

       
        public Category Update([FromBody] Category category , int Id){
            category.CategoryId = Id;
            catalogueRepository.Categories.Update(category);
            catalogueRepository.SaveChanges();
            return category;
        }

       
        public void Delete(int Id){
            Category category = getCat(Id);
            catalogueRepository.Categories.Remove(category);
            catalogueRepository.SaveChanges();
        }


    }
}