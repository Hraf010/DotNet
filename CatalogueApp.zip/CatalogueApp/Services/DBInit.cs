using CatalogueApp.Models;
using System;
namespace CatalogueApp.Services{
    public static class DBInit{
        public static void initData(CatalogueDBRepository catalogueDB){
            Console.WriteLine("Data initialization...");
            catalogueDB.Categories.Add(new Category{Name="Ordinateurs"});
            catalogueDB.Categories.Add(new Category{Name="Telephones"});
            
            catalogueDB.Products.Add(new Product{Name="HP 555", Price = 5000.0,CategoryId=1});
            catalogueDB.Products.Add(new Product{Name="DELL 555", Price = 6000.0,CategoryId=1});
            catalogueDB.Products.Add(new Product{Name="SAMSUNG 555", Price = 7000.0,CategoryId=2});
            catalogueDB.Products.Add(new Product{Name="HUAWEI 555", Price = 8000.0,CategoryId=2});


            
            
            
            catalogueDB.SaveChanges();



        }
    }
}