
using CatalogueApp.Models;
using Microsoft.EntityFrameworkCore;

namespace CatalogueApp
{
    public class CatalogueDBRepository : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products{get; set;}
        public CatalogueDBRepository(DbContextOptions options):base(options)
        {

        }
    }
}